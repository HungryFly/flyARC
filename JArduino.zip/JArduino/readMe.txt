-1. Copy the JArduino folder (located in the distribution in org.sintef.jarduino.samples/arduino) into /libraries/
+1. Copy the JArduino folder (located in the distribution in jarduino.core/src/main/arduino/ into your arduino working directory at Arduino/libraries/
 2. Launch your Arduino environment
 3. File -> Examples -> JArduino -> JArduino firmware. It should open an Arduino program that you should upload to your board using the normal Arduino procedure.
 4. Your Arduino board is now ready for Jarduino. You can exit the Arduino environment forever and launch Eclipse. Just run the Java/JArduino program.